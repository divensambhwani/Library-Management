<html>
<head>
<title>
get_delete_details.php
</title>
<link rel="stylesheet" type="text/css" href="lib_styles.css">
</head>

<body>
<div>
<img src="sclib.jpg" class="img2">
<br><br><h2><u><b>Halifax Science Library</b></u></h2>
</div>
	<center>
<br><br><br>
<div class="menubox">
<br><br><br><br><br><br>
<style type="text/css">
	tab1 { padding-left: 4em; }
	tab2 { padding-left: 1em; }
</style>
<form action="delete_details.php" method="POST">
<b>Transaction NO:</b>
<tab2><input type="text" name="transaction_no"></tab2>
<p>
<input type="submit" value="Delete">
</form>

</body>

<b><tab1><a href="main.php">Home</a></p></tab1></b>
</center>
</html>
