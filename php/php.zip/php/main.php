<html>
<head>
<title>
Main Page
</title>
<link rel="stylesheet" type="text/css" href="lib_styles.css">
</head>

<body>

<div class="header">
<hr><h1><marquee><b>Halifax Science Library</b></marquee></h1></hr>
</div>
<div class="menubox">
<img src="icon.png" class="img">
<br><br><br><br><br><br>

<table id="menu" align=center>
   <tr id="row1">	
    <td><a href="get_data.php"><img src="showdata.png" class="img1"></a></td>
   <td><a href="get_article_details.php"><img src="addart.jpg" class="img1"></a></td>
    <td><a href="get_customer_details.php"><img src="cust.png" class="img1"></a></td>
 <td><a href="get_transaction_details.php"><img src="transaction.png" class="img1"></a></td>
   <td><a href="get_delete_details.php"><img src="delete.png" class="img1"></a></td></tr>
<tr id="row2"><td>SHOW DATA</td>
<td>ADD ARTICLE</td>
<td> ADD NEW CUSTOMER</td>
<td>ADD NEW TRANSACTION</td>
<td> CANCEL TRANSACTION</td>
</tr>
</center>
 
 </table>
 </div>	

</body>

</html>
