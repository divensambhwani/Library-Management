	<?php
        $host="dev.cs.smu.ca";
        $user = "dk_sambhwani";
		$pass = "A00425915";
		$db = "dk_sambhwani";
	?>
